<template>
    <div id="shop">
        <h1>我是shop页面</h1>
    </div>
</template>

<script type="text/ecmascript-6">
    export default{
        name: 'shop',
    }
</script>

<style>

</style>